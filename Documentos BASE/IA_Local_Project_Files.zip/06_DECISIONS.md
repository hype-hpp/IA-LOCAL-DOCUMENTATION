# IA Local — Decisions

## DECISION 001 — Local-first

### Decisão
O sistema será local-first.

### Regra
Modelos locais e infraestrutura local são o padrão. Cloud pode ser utilizada como fallback quando trouxer benefício significativo.

### Status
DEFINITIVA

---

## DECISION 002 — Agentic architecture

### Decisão
O projeto será construído como um sistema agentic, não apenas como chatbot/RAG.

### Componentes principais
- planner
- model router
- memory
- tools
- research controller
- verifier

### Status
DEFINITIVA

---

## DECISION 003 — Hybrid retrieval

### Decisão
O retrieval final será híbrido:

- dense
- sparse/BM25
- metadata filtering
- reranking

### Status
DEFINITIVA

---

## DECISION 004 — PostgreSQL + Qdrant

### Decisão
Usar PostgreSQL para dados estruturados e Qdrant para dados vetoriais.

### Status
DEFINITIVA

---

## DECISION 005 — Sandbox

### Decisão
Execução de código ocorrerá em ambiente isolado, inicialmente Docker.

### Regra
Nenhum agente terá acesso direto ao filesystem pessoal do usuário.

### Status
DEFINITIVA

---

## DECISION 006 — GPT-OSS como forte candidato a padrão

### Motivo
Benchmark de velocidade muito superior aos outros modelos testados.

### Resultado observado
140 tok/s em 2K e 16K.

### Status
PROVISÓRIA — aguarda benchmark de qualidade.

---

## DECISION 007 — Qwen3-Coder como especialista

### Motivo
MoE, 3.3B ativos e bom desempenho/velocidade relativa no hardware.

### Status
PROVISÓRIA — aguarda benchmark de qualidade e coding benchmark.

---

## DECISION 008 — Qwen3.6 não será o modelo padrão

### Motivo
~8.9 tok/s em 2K e ~5.5 tok/s em 64K no hardware atual.

### Possível uso
Reasoning pesado sob demanda.

### Status
PROVISÓRIA

---

## DECISION 009 — Crawler adaptativo

### Decisão
O crawler poderá receber parâmetros definidos pelo próprio agente:

- profundidade
- máximo de páginas
- tópicos
- exclusões
- domínios
- orçamento

O agente também poderá decidir quando há evidência suficiente.

### Status
DEFINITIVA

---

## DECISION 010 — Verifier condicional

### Decisão
O verifier não será executado obrigatoriamente em toda resposta.

### Regra
Entrará principalmente em:
- pesquisa profunda
- tarefas críticas
- respostas com alta incerteza
- cenários configurados pelo usuário

### Status
DEFINITIVA
