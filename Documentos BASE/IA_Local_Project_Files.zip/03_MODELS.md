# IA Local — Models

## Regra

Os papéis dos modelos ainda são provisórios até o benchmark de qualidade.

## GPT-OSS 20B

### Candidato a

- modelo geral
- agente principal
- tarefas rápidas
- fallback

### Benchmark de velocidade

| Contexto | Velocidade |
|---:|---:|
| 2K | 140 tok/s |
| 16K | 140 tok/s |
| 64K | 120 tok/s |

### Offload

- 100% GPU no teste informado
- Começou a estourar o espaço de VRAM somente em contexto maior

### Situação

**Forte candidato a modelo padrão por desempenho/latência.**

---

## Qwen3-Coder 30B

### Candidato a

- coding
- debugging
- tarefas pesadas de software
- segunda opção de uso geral pesado

### Benchmark de velocidade

| Contexto | Velocidade |
|---:|---:|
| 2K | 82 tok/s |
| 16K | 72 tok/s |
| 64K | 45 tok/s |

### Arquitetura

- MoE
- ~30B parâmetros totais
- ~3.3B parâmetros ativos

### Offload

- Teste informado: ~27% GPU / 73% CPU

### Situação

**Forte candidato a especialista de código.**

---

## Qwen3.6 27B

### Candidato a

- reasoning pesado
- tarefa excepcional em que qualidade pode justificar latência

### Benchmark de velocidade

| Contexto | Velocidade |
|---:|---:|
| 2K | 8.9 tok/s |
| 16K | 7.7 tok/s |
| 64K | 5.5 tok/s |

### Arquitetura

- denso
- ~27.8B parâmetros

### Offload

- teste informado: ~24% GPU / 76% CPU

### Situação

**Não recomendado como modelo padrão neste hardware.**
Uso potencial: tarefas raras de máxima qualidade.

---

## Qwen3-VL 8B

### Candidato a

- visão
- OCR
- análise de screenshots
- percepção visual

### Situação

Especialista visual opcional.

---

## Qwen3-Embedding 4B

### Candidato a

- embeddings de documentos
- embeddings de memória
- retrieval

### Situação

Candidato principal para embedding.

---

## Decisão provisória de routing

```text
Tarefa normal / interação rápida
    -> GPT-OSS 20B

Coding / debugging
    -> Qwen3-Coder 30B

Reasoning muito pesado e excepcional
    -> Qwen3.6 27B

Vision
    -> Qwen3-VL 8B ou Qwen3.6 multimodal

Embedding
    -> Qwen3-Embedding 4B
```

Essa política só deve ser marcada como definitiva após benchmark de qualidade.
